<?php 

echo
'<header class="container-fluid p-0 sticky-top" >
  <nav class="navbar navbar-expand-lg" style="Background-color: #43847b">
      <div class="container" >
        <a class="navbar-brand fw-bold" href="/praktikum-pemweb/PPW-24-06_L0122147_SalsaRizkiSaputri" style="color: #cdfadb">School Inventory</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        
        ';

echo
      '</div>
  </nav>
</header>';
?>


